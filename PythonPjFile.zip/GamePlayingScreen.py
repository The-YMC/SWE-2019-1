# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'GamePlaying.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

# 게임 진행 Display
# @Yeomin

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QGraphicsOpacityEffect
from Userss import User as user
from yutnori_map import Map as mp


class UI_Dialog_03(object):

    def __init__(self):
        a = 0
    def update(self, maplist):
        temp_list = []
        for i in range(29):
            temp_list[i] = maplist[i]
            print[temp_list[i]]

    def updating(self,m):
        return m;



    temp_list = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]



    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1020, 800)                                    # 화면 크기 1020*800
        self.graphicsView = QtWidgets.QGraphicsView(Dialog)
        self.graphicsView.setGeometry(QtCore.QRect(0, 0, 1021, 801))
        self.graphicsView.setObjectName("graphicsView")
        self.AddPiece = QtWidgets.QPushButton(Dialog)
        self.AddPiece.setGeometry(QtCore.QRect(720, 590, 121, 71))
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(20)
        self.AddPiece.setFont(font)                                 # 말 추가 기능 버튼 - 누르면 말이 추가되도록
        self.AddPiece.setObjectName("AddPiece")
        self.Roll = QtWidgets.QPushButton(Dialog)
        self.Roll.setGeometry(QtCore.QRect(850, 590, 121, 71))
        self.Roll.clicked.connect(isRollClicked)
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(20)
        self.Roll.setFont(font)
        self.Roll.setObjectName("Roll")                             # 윷 던지기 버튼 - 누르면 랜덤으로 윷이 도~모까지 나온다
        self.Rolling_Yut = QtWidgets.QLabel(Dialog)
        self.Rolling_Yut.setGeometry(QtCore.QRect(10, 720, 191, 61))
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(20)
        self.Rolling_Yut.setFont(font)                              # 지정 윷 던지기 글씨 - 안건드려도 됨
        self.Rolling_Yut.setAlignment(QtCore.Qt.AlignCenter)
        self.Rolling_Yut.setObjectName("Rolling_Yut")
        self.Do_Btn = QtWidgets.QPushButton(Dialog)
        self.Do_Btn.setGeometry(QtCore.QRect(210, 730, 71, 41))
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(20)
        self.Do_Btn.setFont(font)                                    # 지정 윷 던지기 - 도
        self.Do_Btn.setObjectName("Do_Btn")
        self.Ge_btn = QtWidgets.QPushButton(Dialog)
        self.Ge_btn.setGeometry(QtCore.QRect(300, 730, 71, 41))
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(20)
        self.Ge_btn.setFont(font)                                   # 지정 윷 던지기 - 개
        self.Ge_btn.setObjectName("Ge_btn")
        self.Gul_btn = QtWidgets.QPushButton(Dialog)
        self.Gul_btn.setGeometry(QtCore.QRect(390, 730, 71, 41))
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(20)
        self.Gul_btn.setFont(font)                                  # 지정 윷 던지기 - 걸
        self.Gul_btn.setObjectName("Gul_btn")
        self.Yut_btn = QtWidgets.QPushButton(Dialog)
        self.Yut_btn.setGeometry(QtCore.QRect(480, 730, 71, 41))
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(20)
        self.Yut_btn.setFont(font)                                  # 지정 윷 던지기 - 윷
        self.Yut_btn.setObjectName("Yut_btn")
        self.Mo_btn = QtWidgets.QPushButton(Dialog)
        self.Mo_btn.setGeometry(QtCore.QRect(570, 730, 71, 41))
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(20)
        self.Mo_btn.setFont(font)                                  # 지정 윷 던지기 - 모
        self.Mo_btn.setObjectName("Mo_btn")
        self.BackDo_btn = QtWidgets.QPushButton(Dialog)  # 지정 윷 던지기 - 빽도
        self.BackDo_btn.setGeometry(QtCore.QRect(660, 730, 71, 41))
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(20)
        self.BackDo_btn.setFont(font)
        self.BackDo_btn.setObjectName("BackDo_btn")
        self.Yut_Board = QtWidgets.QLabel(Dialog)                   # 윷놀이 보드판
        self.Yut_Board.setGeometry(QtCore.QRect(70, 60, 611, 611))
        self.Yut_Board.setObjectName("Yut_Board")
        self.Do = QtWidgets.QLabel(Dialog)                          # 그림 - 도
        self.Do.setGeometry(QtCore.QRect(780, 480, 131, 101))
        self.Do.setObjectName("Do")
        self.BackDo = QtWidgets.QLabel(Dialog)                      # 그림 - 빽도
        self.BackDo.setGeometry(QtCore.QRect(780, 480, 141, 101))
        self.BackDo.setObjectName("BackDo")
        self.Ge = QtWidgets.QLabel(Dialog)                          # 그림 - 개
        self.Ge.setGeometry(QtCore.QRect(780, 480, 141, 101))
        self.Ge.setObjectName("Ge")
        self.Gul = QtWidgets.QLabel(Dialog)                         # 걸 그림 - 각 단계별 그림이 있으니 if문 같은것으로 조절하면  될듯
        self.Gul.setGeometry(QtCore.QRect(780, 480, 141, 101))
        self.Gul.setObjectName("Gul")
        self.Yut = QtWidgets.QLabel(Dialog)                          # 윷 그림
        self.Yut.setGeometry(QtCore.QRect(780, 480, 141, 101))
        self.Yut.setObjectName("Yut")
        self.Mo = QtWidgets.QLabel(Dialog)                           # 모 그림
        self.Mo.setGeometry(QtCore.QRect(780, 480, 141, 101))
        self.Mo.setObjectName("Mo")
        self.Player01 = QtWidgets.QLabel(Dialog)                    #첫 번째 플레이어 - 말 5개
        self.Player01.setGeometry(QtCore.QRect(690, 40, 141, 151))
        self.Player01.setObjectName("Player01")
        self.Player01_2 = QtWidgets.QLabel(Dialog)
        self.Player01_2.setGeometry(QtCore.QRect(750, 40, 141, 151))
        self.Player01_2.setObjectName("Player01_2")
        self.Player01_3 = QtWidgets.QLabel(Dialog)
        self.Player01_3.setGeometry(QtCore.QRect(780, 40, 141, 151))
        self.Player01_3.setObjectName("Player01_3")
        self.Player01_4 = QtWidgets.QLabel(Dialog)
        self.Player01_4.setGeometry(QtCore.QRect(810, 40, 141, 151))
        self.Player01_4.setObjectName("Player01_4")
        self.Player01_5 = QtWidgets.QLabel(Dialog)
        self.Player01_5.setGeometry(QtCore.QRect(850, 40, 141, 151))
        self.Player01_5.setObjectName("Player01_5")

        self.Player02 = QtWidgets.QLabel(Dialog)                        #두 번째 플레이어 - 말 5개
        self.Player02.setGeometry(QtCore.QRect(690, 140, 141, 151))
        self.Player02.setObjectName("Player02")
        self.Player02_2 = QtWidgets.QLabel(Dialog)
        self.Player02_2.setGeometry(QtCore.QRect(750, 140, 141, 151))
        self.Player02_2.setObjectName("Player02_2")
        self.Player02_3 = QtWidgets.QLabel(Dialog)
        self.Player02_3.setGeometry(QtCore.QRect(780, 140, 141, 151))
        self.Player02_3.setObjectName("Player02_3")
        self.Player02_4 = QtWidgets.QLabel(Dialog)
        self.Player02_4.setGeometry(QtCore.QRect(810, 140, 141, 151))
        self.Player02_4.setObjectName("Player02_4")
        self.Player02_5 = QtWidgets.QLabel(Dialog)
        self.Player02_5.setGeometry(QtCore.QRect(850, 140, 141, 151))
        self.Player02_5.setObjectName("Player02_5")

        self.Player03 = QtWidgets.QLabel(Dialog)                        #세 번째 플레이어 - 말 5개
        self.Player03.setGeometry(QtCore.QRect(690, 240, 141, 151))
        self.Player03.setObjectName("Player03")
        self.Player03_2 = QtWidgets.QLabel(Dialog)
        self.Player03_2.setGeometry(QtCore.QRect(750, 240, 141, 151))
        self.Player03_2.setObjectName("Player03_2")
        self.Player03_3 = QtWidgets.QLabel(Dialog)
        self.Player03_3.setGeometry(QtCore.QRect(780, 240, 141, 151))
        self.Player03_3.setObjectName("Player03_3")
        self.Player03_4 = QtWidgets.QLabel(Dialog)
        self.Player03_4.setGeometry(QtCore.QRect(810, 240, 141, 151))
        self.Player03_4.setObjectName("Player03_4")
        self.Player03_5 = QtWidgets.QLabel(Dialog)
        self.Player03_5.setGeometry(QtCore.QRect(850, 240, 141, 151))
        self.Player03_5.setObjectName("Player03_5")

        self.Player04 = QtWidgets.QLabel(Dialog)                        #네 번째 플레이어 - 말 5개
        self.Player04.setGeometry(QtCore.QRect(690, 340, 141, 151))
        self.Player04.setObjectName("Player04")
        self.Player04_2 = QtWidgets.QLabel(Dialog)
        self.Player04_2.setGeometry(QtCore.QRect(750, 340, 141, 151))
        self.Player04_2.setObjectName("Player04_2")
        self.Player04_3 = QtWidgets.QLabel(Dialog)
        self.Player04_3.setGeometry(QtCore.QRect(780, 340, 141, 151))
        self.Player04_3.setObjectName("Player04_3")
        self.Player04_4 = QtWidgets.QLabel(Dialog)
        self.Player04_4.setGeometry(QtCore.QRect(810, 340, 141, 151))
        self.Player04_4.setObjectName("Player04_4")
        self.Player04_5 = QtWidgets.QLabel(Dialog)
        self.Player04_5.setGeometry(QtCore.QRect(850, 340, 141, 151))
        self.Player04_5.setObjectName("Player04_5")

 # 여기에서부터는 각 보드의 버튼 0 ~ 28까지 있으며, 그 순서는 yutnori_map의 보드판과 일치
        self.Btn0 = QtWidgets.QPushButton(Dialog)                # 버튼 생성
        self.Btn0.setGeometry(QtCore.QRect(560, 550, 93, 101))     # 버튼 위치 및 사이즈
        self.Btn0.setObjectName("Btn0")                             # 버튼 이름
        opacity_effect = QGraphicsOpacityEffect(self.Btn0)          # 세 줄은 버튼 투명도 조절
        opacity_effect.setOpacity(0.1)
        self.Btn0.setGraphicsEffect(opacity_effect)
        self.Btn0.clicked.connect(button_Click00)


        self.Btn1 = QtWidgets.QPushButton(Dialog)
        self.Btn1.setGeometry(QtCore.QRect(570, 460, 71, 81))
        self.Btn1.setObjectName("Btn1")
        opacity_effect = QGraphicsOpacityEffect(self.Btn1)
        opacity_effect.setOpacity(0.1)
        self.Btn1.setGraphicsEffect(opacity_effect)
        self.Btn1.clicked.connect(button_Click01)

        self.Btn2 = QtWidgets.QPushButton(Dialog)
        self.Btn2.setGeometry(QtCore.QRect(570, 370, 71, 71))
        self.Btn2.setObjectName("Btn2")
        opacity_effect = QGraphicsOpacityEffect(self.Btn2)
        opacity_effect.setOpacity(0.1)
        self.Btn2.setGraphicsEffect(opacity_effect)
        self.Btn2.clicked.connect(button_Click02)

        self.Btn3 = QtWidgets.QPushButton(Dialog)
        self.Btn3.setGeometry(QtCore.QRect(570, 280, 71, 71))
        self.Btn3.setObjectName("Btn3")
        opacity_effect = QGraphicsOpacityEffect(self.Btn3)
        opacity_effect.setOpacity(0.1)
        self.Btn3.setGraphicsEffect(opacity_effect)
        self.Btn3.clicked.connect(button_Click03)

        self.Btn4 = QtWidgets.QPushButton(Dialog)
        self.Btn4.setGeometry(QtCore.QRect(570, 200, 71, 71))
        self.Btn4.setObjectName("Btn4")
        opacity_effect = QGraphicsOpacityEffect(self.Btn4)
        opacity_effect.setOpacity(0.1)
        self.Btn4.setGraphicsEffect(opacity_effect)
        self.Btn4.clicked.connect(button_Click04)

        self.Btn6 = QtWidgets.QPushButton(Dialog)
        self.Btn6.setGeometry(QtCore.QRect(470, 90, 71, 71))
        self.Btn6.setObjectName("Btn6")
        opacity_effect = QGraphicsOpacityEffect(self.Btn6)
        opacity_effect.setOpacity(0.1)
        self.Btn6.setGraphicsEffect(opacity_effect)
        self.Btn6.clicked.connect(button_Click06)

        self.Btn19 = QtWidgets.QPushButton(Dialog)
        self.Btn19.setGeometry(QtCore.QRect(470, 560, 71, 71))
        self.Btn19.setObjectName("Btn19")
        opacity_effect = QGraphicsOpacityEffect(self.Btn19)
        opacity_effect.setOpacity(0.1)
        self.Btn19.setGraphicsEffect(opacity_effect)
        self.Btn19.clicked.connect(button_Click19)

        self.Btn18 = QtWidgets.QPushButton(Dialog)
        self.Btn18.setGeometry(QtCore.QRect(380, 560, 71, 71))
        self.Btn18.setObjectName("Btn18")
        opacity_effect = QGraphicsOpacityEffect(self.Btn18)
        opacity_effect.setOpacity(0.1)
        self.Btn18.setGraphicsEffect(opacity_effect)
        self.Btn18.clicked.connect(button_Click18)

        self.Btn17 = QtWidgets.QPushButton(Dialog)
        self.Btn17.setGeometry(QtCore.QRect(290, 560, 71, 71))
        self.Btn17.setObjectName("Btn17")
        opacity_effect = QGraphicsOpacityEffect(self.Btn17)
        opacity_effect.setOpacity(0.1)
        self.Btn17.setGraphicsEffect(opacity_effect)
        self.Btn17.clicked.connect(button_Click17)

        self.Btn16 = QtWidgets.QPushButton(Dialog)
        self.Btn16.setGeometry(QtCore.QRect(200, 560, 71, 71))
        self.Btn16.setObjectName("Btn16")
        opacity_effect = QGraphicsOpacityEffect(self.Btn16)
        opacity_effect.setOpacity(0.1)
        self.Btn16.setGraphicsEffect(opacity_effect)
        self.Btn16.clicked.connect(button_Click16)

        self.Btn14 = QtWidgets.QPushButton(Dialog)
        self.Btn14.setGeometry(QtCore.QRect(100, 460, 71, 71))
        self.Btn14.setObjectName("Btn14")
        opacity_effect = QGraphicsOpacityEffect(self.Btn14)
        opacity_effect.setOpacity(0.1)
        self.Btn14.setGraphicsEffect(opacity_effect)
        self.Btn14.clicked.connect(button_Click14)

        self.Btn13 = QtWidgets.QPushButton(Dialog)
        self.Btn13.setGeometry(QtCore.QRect(100, 370, 71, 71))
        self.Btn13.setObjectName("Btn13")
        opacity_effect = QGraphicsOpacityEffect(self.Btn13)
        opacity_effect.setOpacity(0.1)
        self.Btn13.setGraphicsEffect(opacity_effect)
        self.Btn13.clicked.connect(button_Click13)

        self.Btn12 = QtWidgets.QPushButton(Dialog)
        self.Btn12.setGeometry(QtCore.QRect(100, 290, 71, 71))
        self.Btn12.setObjectName("Btn12")
        opacity_effect = QGraphicsOpacityEffect(self.Btn12)
        opacity_effect.setOpacity(0.1)
        self.Btn12.setGraphicsEffect(opacity_effect)
        self.Btn12.clicked.connect(button_Click12)

        self.Btn11 = QtWidgets.QPushButton(Dialog)
        self.Btn11.setGeometry(QtCore.QRect(100, 200, 71, 71))
        self.Btn11.setObjectName("Btn11")
        opacity_effect = QGraphicsOpacityEffect(self.Btn11)
        opacity_effect.setOpacity(0.1)
        self.Btn11.setGraphicsEffect(opacity_effect)
        self.Btn11.clicked.connect(button_Click11)

        self.Btn23 = QtWidgets.QPushButton(Dialog)
        self.Btn23.setGeometry(QtCore.QRect(180, 480, 71, 71))
        self.Btn23.setObjectName("Btn23")
        opacity_effect = QGraphicsOpacityEffect(self.Btn23)
        opacity_effect.setOpacity(0.1)
        self.Btn23.setGraphicsEffect(opacity_effect)
        self.Btn23.clicked.connect(button_Click23)

        self.Btn27 = QtWidgets.QPushButton(Dialog)
        self.Btn27.setGeometry(QtCore.QRect(480, 480, 71, 71))
        self.Btn27.setObjectName("Btn27")
        opacity_effect = QGraphicsOpacityEffect(self.Btn27)
        opacity_effect.setOpacity(0.1)
        self.Btn27.setGraphicsEffect(opacity_effect)
        self.Btn27.clicked.connect(button_Click27)

        self.Btn26 = QtWidgets.QPushButton(Dialog)
        self.Btn26.setGeometry(QtCore.QRect(420, 410, 71, 71))
        self.Btn26.setObjectName("Btn26")
        opacity_effect = QGraphicsOpacityEffect(self.Btn26)
        opacity_effect.setOpacity(0.1)
        self.Btn26.setGraphicsEffect(opacity_effect)
        self.Btn26.clicked.connect(button_Click26)

        self.Btn22 = QtWidgets.QPushButton(Dialog)
        self.Btn22.setGeometry(QtCore.QRect(250, 410, 71, 71))
        self.Btn22.setObjectName("Btn22")
        opacity_effect = QGraphicsOpacityEffect(self.Btn22)
        opacity_effect.setOpacity(0.1)
        self.Btn22.setGraphicsEffect(opacity_effect)
        self.Btn22.clicked.connect(button_Click22)

        self.Btn20 = QtWidgets.QPushButton(Dialog)
        self.Btn20.setGeometry(QtCore.QRect(490, 180, 71, 71))
        self.Btn20.setObjectName("Btn20")
        opacity_effect = QGraphicsOpacityEffect(self.Btn20)
        opacity_effect.setOpacity(0.1)
        self.Btn20.setGraphicsEffect(opacity_effect)
        self.Btn20.clicked.connect(button_Click20)

        self.Btn21 = QtWidgets.QPushButton(Dialog)
        self.Btn21.setGeometry(QtCore.QRect(420, 240, 71, 71))
        self.Btn21.setObjectName("Btn21")
        opacity_effect = QGraphicsOpacityEffect(self.Btn21)
        opacity_effect.setOpacity(0.1)
        self.Btn21.setGraphicsEffect(opacity_effect)
        self.Btn21.clicked.connect(button_Click21)

        self.Btn24 = QtWidgets.QPushButton(Dialog)
        self.Btn24.setGeometry(QtCore.QRect(190, 180, 71, 71))
        self.Btn24.setObjectName("Btn24")
        opacity_effect = QGraphicsOpacityEffect(self.Btn24)
        opacity_effect.setOpacity(0.1)
        self.Btn24.setGraphicsEffect(opacity_effect)
        self.Btn24.clicked.connect(button_Click24)

        self.Btn25 = QtWidgets.QPushButton(Dialog)
        self.Btn25.setGeometry(QtCore.QRect(260, 240, 71, 71))
        self.Btn25.setObjectName("Btn25")
        opacity_effect = QGraphicsOpacityEffect(self.Btn25)
        opacity_effect.setOpacity(0.1)
        self.Btn25.setGraphicsEffect(opacity_effect)
        self.Btn25.clicked.connect(button_Click25)

        self.Btn7 = QtWidgets.QPushButton(Dialog)
        self.Btn7.setGeometry(QtCore.QRect(380, 90, 71, 71))
        self.Btn7.setObjectName("Btn7")
        opacity_effect = QGraphicsOpacityEffect(self.Btn7)
        opacity_effect.setOpacity(0.1)
        self.Btn7.setGraphicsEffect(opacity_effect)
        self.Btn7.clicked.connect(button_Click07)


        self.Btn8 = QtWidgets.QPushButton(Dialog)
        self.Btn8.setGeometry(QtCore.QRect(290, 90, 71, 71))
        self.Btn8.setObjectName("Btn8")
        opacity_effect = QGraphicsOpacityEffect(self.Btn8)
        opacity_effect.setOpacity(0.1)
        self.Btn8.setGraphicsEffect(opacity_effect)
        self.Btn8.clicked.connect(button_Click08)

        self.Btn9 = QtWidgets.QPushButton(Dialog)
        self.Btn9.setGeometry(QtCore.QRect(200, 90, 71, 71))
        self.Btn9.setObjectName("Btn9")
        opacity_effect = QGraphicsOpacityEffect(self.Btn9)
        opacity_effect.setOpacity(0.1)
        self.Btn9.setGraphicsEffect(opacity_effect)
        self.Btn9.clicked.connect(button_Click09)

        self.Btn5 = QtWidgets.QPushButton(Dialog)
        self.Btn5.setGeometry(QtCore.QRect(560, 80, 93, 101))
        self.Btn5.setObjectName("Btn5")
        opacity_effect = QGraphicsOpacityEffect(self.Btn5)
        opacity_effect.setOpacity(0.1)
        self.Btn5.setGraphicsEffect(opacity_effect)
        self.Btn5.clicked.connect(button_Click05)

        self.Btn28 = QtWidgets.QPushButton(Dialog)
        self.Btn28.setGeometry(QtCore.QRect(322, 310, 101, 101))
        self.Btn28.setObjectName("Btn28")
        opacity_effect = QGraphicsOpacityEffect(self.Btn28)
        opacity_effect.setOpacity(0.1)
        self.Btn28.setGraphicsEffect(opacity_effect)
        self.Btn28.clicked.connect(button_Click28)

        self.Btn15 = QtWidgets.QPushButton(Dialog)
        self.Btn15.setGeometry(QtCore.QRect(90, 550, 93, 101))
        self.Btn15.setObjectName("Btn15")
        opacity_effect = QGraphicsOpacityEffect(self.Btn15)
        opacity_effect.setOpacity(0.1)
        self.Btn15.setGraphicsEffect(opacity_effect)
        self.Btn15.clicked.connect(button_Click15)

        self.Btn10 = QtWidgets.QPushButton(Dialog)
        self.Btn10.setGeometry(QtCore.QRect(90, 80, 93, 101))
        self.Btn10.setObjectName("Btn10")
        opacity_effect = QGraphicsOpacityEffect(self.Btn10)
        opacity_effect.setOpacity(0.1)
        self.Btn10.setGraphicsEffect(opacity_effect)
        self.Btn10.clicked.connect(button_Click10)



        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        return  True
# 각 버튼 및 레이블의 글자
    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.AddPiece.setText(_translate("Dialog", "말 추가"))
        self.Roll.setText(_translate("Dialog", "윷 던지기"))
        self.Rolling_Yut.setText(_translate("Dialog", "지정 윷 던지기"))
        self.Do_Btn.setText(_translate("Dialog", "도"))
        self.Ge_btn.setText(_translate("Dialog", "개"))
        self.Gul_btn.setText(_translate("Dialog", "걸"))
        self.Yut_btn.setText(_translate("Dialog", "윷"))
        self.Mo_btn.setText(_translate("Dialog", "모"))
        self.Yut_Board.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/Yut_Board2.jpg\"/></p></body></html>"))
        self.Do.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/DO.png\"/></p></body></html>"))
        self.BackDo.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/BackDO.png\"/></p></body></html>"))
        self.Ge.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/GE.png\"/></p></body></html>"))
        self.BackDo_btn.setText(_translate("Dialog", "빽도"))
        self.Gul.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/GUL.png\"/></p></body></html>"))
        self.Yut.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/YUT.png\"/></p></body></html>"))
        self.Mo.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/MO.png\"/></p></body></html>"))
        self.Player01.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player01_1.png\"/></p></body></html>"))
        self.Player02.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player02_1.png\"/></p></body></html>"))
        self.Player03.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player03_1.png\"/></p></body></html>"))
        self.Player04.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player04_1.png\"/></p></body></html>"))
        self.Player01_2.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player01_1.png\"/></p></body></html>"))
        self.Player01_3.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player01_1.png\"/></p></body></html>"))
        self.Player01_4.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player01_1.png\"/></p></body></html>"))
        self.Player01_5.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player01_1.png\"/></p></body></html>"))
        self.Player02_2.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player02_1.png\"/></p></body></html>"))
        self.Player02_3.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player02_1.png\"/></p></body></html>"))
        self.Player02_4.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player02_1.png\"/></p></body></html>"))
        self.Player02_5.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player02_1.png\"/></p></body></html>"))
        self.Player03_2.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player03_1.png\"/></p></body></html>"))
        self.Player03_3.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player03_1.png\"/></p></body></html>"))
        self.Player03_4.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player03_1.png\"/></p></body></html>"))
        self.Player03_5.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player03_1.png\"/></p></body></html>"))
        self.Player04_2.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player04_1.png\"/></p></body></html>"))
        self.Player04_3.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player04_1.png\"/></p></body></html>"))
        self.Player04_4.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player04_1.png\"/></p></body></html>"))
        self.Player04_5.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/player04_1.png\"/></p></body></html>"))


 # 여기에서부터는 각 버튼의 글씨
 # 단, 글씨가 있으면 투명도를 낮춰도 지저분하기 때문에 글씨는 제거함
"""
        self.Btn0.setText(_translate("Dialog", "0"))
        self.Btn1.setText(_translate("Dialog", "1"))
        self.Btn2.setText(_translate("Dialog", "2"))
        self.Btn3.setText(_translate("Dialog", "3"))
        self.Btn4.setText(_translate("Dialog", "4"))
        self.Btn6.setText(_translate("Dialog", "6"))
        self.Btn19.setText(_translate("Dialog", "19"))
        self.Btn18.setText(_translate("Dialog", "18"))
        self.Btn17.setText(_translate("Dialog", "17"))
        self.Btn16.setText(_translate("Dialog", "16"))
        self.Btn14.setText(_translate("Dialog", "14"))
        self.Btn13.setText(_translate("Dialog", "13"))
        self.Btn12.setText(_translate("Dialog", "12"))
        self.Btn11.setText(_translate("Dialog", "11"))
        self.Btn23.setText(_translate("Dialog", "23"))
        self.Btn27.setText(_translate("Dialog", "27"))
        self.Btn26.setText(_translate("Dialog", "26"))
        self.Btn22.setText(_translate("Dialog", "22"))
        self.Btn20.setText(_translate("Dialog", "20"))
        self.Btn21.setText(_translate("Dialog", "21"))
        self.Btn24.setText(_translate("Dialog", "24"))
        self.Btn25.setText(_translate("Dialog", "25"))
        self.Btn7.setText(_translate("Dialog", "7"))
        self.Btn8.setText(_translate("Dialog", "8"))
        self.Btn9.setText(_translate("Dialog", "9"))
        self.Btn5.setText(_translate("Dialog", "5"))
        self.Btn28.setText(_translate("Dialog", "28"))
        self.Btn15.setText(_translate("Dialog", "15"))
        self.Btn10.setText(_translate("Dialog", "10"))
        
        def updaate(self, maplist):
        temp_list = []
        
        
        for i in range(29):        
"""
def button_Click00():
    return 0;

def button_Click01():
    return 1;

def button_Click02():
    return 2;

def button_Click03():
    return 3;

def button_Click04():
    return 4;

def button_Click05():
    return 5;

def button_Click06():
    return 6;

def button_Click07():
    return 7;

def button_Click08():
    return 8;

def button_Click09():
    return 9;

def button_Click10():
    return 10;

def button_Click11():
    return 11;

def button_Click12():
    return 12;

def button_Click13():
    return 13;

def button_Click14():
    return 14;

def button_Click15():
    return 15;

def button_Click16():
    return 16;

def button_Click17():
    return 17;

def button_Click18():
    return 18;

def button_Click19():
    return 19;

def button_Click20():
    return 20;

def button_Click21():
    return 21;

def button_Click22():
    return 22;

def button_Click23():
    return 23;

def button_Click24():
    return 24;

def button_Click25():
    return 25;

def button_Click26():
    return 26;

def button_Click27():
    return 27;

def button_Click28():
    return 28;

def isRollClicked():
    return True




def UI_Display(Dialog00):  # 한 UI에서 다른 UI띄울 때 사용할 함수
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Dialog00()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

import myres_rc
"""
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = UI_Dialog_03()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
"""





