from PyQt5.QtWidgets import QApplication, QWidget, QPushButton
from PyQt5.QtCore import QCoreApplication
from PyQt5 import QtCore, QtGui, QtWidgets
import PlayerInfoScreen as pi
import FirstScreen as fs
import GamePlayingScreen as gp
import yutnori_map
import Userss
import sys
import random

map = yutnori_map.Map()
user = Userss.User()

tftf = False


class Controller():

    def Game(self):
        GameInit = True

        rollResult = -5
        tftf = False

        if(GameInit):
            print("a")
            if(map.winner != -1):
                GameInit = False # 게임 종료 조건
            print("c")
            if(gp.UI_Dialog_03.setupUi == True):
                tftf = True # 윷던지기 버튼이 클릭 되었을 때 gp.UI_Dialog_03이 True값 반환

            """
            while(True):
                index = 0
                if (gp.UI_Dialog_03.setupUi == True and index == 0):
                    self.t_select()
                    gp.UI_Dialog_03.setupUi = False
                    index = index + 1
                #if
            """
    def t_select(self):
        a = 1




if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    uidiag = fs.UI_Dialog_01()
    ui = uidiag
    ui.setupUi(Dialog)
    Dialog.show()
    ctrl = Controller()
    ctrl.Game()

    sys.exit(app.exec_())
