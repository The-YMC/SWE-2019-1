from PyQt5.QtWidgets import QApplication, QWidget, QPushButton
from PyQt5.QtCore import QCoreApplication
from PyQt5 import QtCore, QtGui, QtWidgets
import PlayerInfoScreen as pi
import FirstScreen as fs
import GamePlayingScreen as gp
import yutnori_map
import Userss
import sys

map = yutnori_map.Map()
user = Userss.User()




class Controller():

    def Game(self):
        GameInit = True

        rollResult = -5

        if(GameInit):
            print("a")
            if(map.winner != -1):
                GameInit = False
            if(gp.UI_Dialog_03 == True): # 윷던지기 버튼이 클릭 되었을 때 gp.UI_Dialog_03이 True값 반환
                rollResult = user.roll()
                print("b")
                mapIndex = gp.UI_Dialog_03
                #userinfo
                map.select(rollResult, mapIndex, 1) # user_info 추가할것
                print("c")
            while(1):
             if (gp.UI_Dialog_03 == True):
                rollResult = user.roll()
                print("b")
                mapIndex = gp.UI_Dialog_03
                # userinfo
                map.select(rollResult, mapIndex, 1)  # user_info 추가할것
                print("c")
                gp.UI_Dialog_03 = False






       # map.select(n_roll, map_index, user_info)








if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    uidiag = fs.UI_Dialog_01()
    ui = uidiag
    ui.setupUi(Dialog)
    Dialog.show()
    ctrl = Controller()
    ctrl.Game()

    sys.exit(app.exec_())
