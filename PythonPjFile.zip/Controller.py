from PyQt5.QtWidgets import QApplication, QWidget, QPushButton
from PyQt5.QtCore import QCoreApplication
from PyQt5 import QtCore, QtGui, QtWidgets
import GamePlayingScreen as gm
import PlayerInfoScreen as pi
import FirstScreen as fs
import yutnori_map as map
import sys


class Controller():

    def __init__(self, GameInit):
        GameInit = False




























