# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'yutnori01.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!


# 맨 처음 화면 Display
# Start 버튼을 누르면 플레이어의 정보를 입력받는 playerinfo.py의 클래스가 수행되고
# Exit을 누르면 게임 화면이 종료되게!
# @Yeomin

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton
from PyQt5.QtCore import QCoreApplication
from PlayerInfoScreen import UI_Dialog_02 as pi
import sys

class UI_Dialog_01(object):

    def ChangeUI(self):  # 한 UI에서 다른 UI띄울 때 사용할 함수
        self.app = QtWidgets.QApplication(sys.argv)
        self.Dialog = QtWidgets.QDialog()
        t = pi()
        self.ui = t
        self.ui.setupUi(self.Dialog)
        Dialog.hide()
        self.Dialog.show()


    def setupUi(self, Dialog):
        Dialog.setObjectName("YutNori")
        Dialog.resize(1020, 800)                                    # 화면 크기 1020*800
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(360, 60, 291, 121))
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(72)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.start = QtWidgets.QPushButton(Dialog)                      # Start버튼
        self.start.setGeometry(QtCore.QRect(230, 600, 191, 71))
        self.start.clicked.connect(self.ChangeUI)
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(28)
        self.start.setFont(font)
        self.start.setObjectName("start")
        self.Exit = QtWidgets.QPushButton(Dialog)                     # Exit버튼
        self.Exit.setGeometry(QtCore.QRect(580, 600, 191, 71))
        self.Exit.clicked.connect(QCoreApplication.instance().quit)
        font = QtGui.QFont()
        font.setFamily("배달의민족 주아")
        font.setPointSize(28)
        self.Exit.setFont(font)
        self.Exit.setObjectName("Exit")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(230, 200, 541, 381))
        self.label_2.setObjectName("label_2")
        self.graphicsView = QtWidgets.QGraphicsView(Dialog)   # 배경 색 흰색으로
        self.graphicsView.setGeometry(QtCore.QRect(0, 0, 1020, 800))
        self.graphicsView.setObjectName("graphicsView")
        self.graphicsView.raise_()
        self.label_2.raise_()
        self.label.raise_()
        self.start.raise_()
        self.Exit.raise_()
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

        import myres_rc

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label.setText(_translate("Dialog", "윷놀이"))
        self.start.setText(_translate("Dialog", "START"))
        self.Exit.setText(_translate("Dialog", "EXIT"))
        self.label_2.setText(_translate("Dialog", "<html><head/><body><p><img src=\":/imgs/yutnori_fam.jpg\"/></p></body></html>"))



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = UI_Dialog_01()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())